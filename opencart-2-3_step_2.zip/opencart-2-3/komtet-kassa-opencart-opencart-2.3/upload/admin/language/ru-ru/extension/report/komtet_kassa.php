<?php
$_['heading_title'] = 'КОМТЕТ Касса';

$_['lang_order_id'] = 'Заказ';
$_['lang_status'] = 'Статус';
$_['lang_error'] = 'Ошибка';

$_['lang_success'] = 'Успешно';
$_['lang_failed'] = 'Неудачно';

$_['lang_no_data'] = 'Нет данных';
