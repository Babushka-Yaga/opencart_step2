<?php

$_['heading_title'] = 'KOMTET Kassa';

$_['lang_order_id'] = 'Order ID';
$_['lang_status'] = 'Status';
$_['lang_error'] = 'Error';

$_['lang_success'] = 'Success';
$_['lang_failed'] = 'Failed';

$_['lang_no_data'] = 'There are no data to display';
